for (let i = 0; i < 3; i++) {
    setTimeout(() => {
        console.log(i)
    }, 1)
}

const a = 'a'
const c = String('a')

console.log(c)